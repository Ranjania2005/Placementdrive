-- Placement Drive Management System Database Schema

-- Create Database
CREATE DATABASE IF NOT EXISTS placement_db;
USE placement_db;

-- Students Table
CREATE TABLE IF NOT EXISTS students (
    std_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    cgpa DECIMAL(3,2) NOT NULL,
    branch_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Companies Table
CREATE TABLE IF NOT EXISTS companies (
    comp_id INT PRIMARY KEY AUTO_INCREMENT,
    comp_name VARCHAR(100) NOT NULL UNIQUE,
    industry VARCHAR(100) NOT NULL,
    salary DECIMAL(8,2) NOT NULL,
    openings INT NOT NULL,
    min_cgpa DECIMAL(3,2) NOT NULL,
    drive_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Applications Table
CREATE TABLE IF NOT EXISTS applications (
    app_id INT PRIMARY KEY AUTO_INCREMENT,
    std_id INT NOT NULL,
    comp_id INT NOT NULL,
    app_date DATE NOT NULL,
    status VARCHAR(20) DEFAULT 'Applied',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (std_id) REFERENCES students(std_id) ON DELETE CASCADE,
    FOREIGN KEY (comp_id) REFERENCES companies(comp_id) ON DELETE CASCADE,
    UNIQUE KEY unique_application (std_id, comp_id)
);

-- Sample Data
INSERT INTO students (name, email, cgpa, branch_id) VALUES
('Rahul Kumar', 'rahul@college.edu', 8.5, 1),
('Priya Singh', 'priya@college.edu', 7.8, 1),
('Amit Patel', 'amit@college.edu', 9.2, 2),
('Neha Verma', 'neha@college.edu', 7.5, 3),
('Arjun Sharma', 'arjun@college.edu', 8.9, 1),
('Anjali Gupta', 'anjali@college.edu', 6.8, 2);

INSERT INTO companies (comp_name, industry, salary, openings, min_cgpa, drive_date) VALUES
('Tech Corp', 'IT', 12.5, 10, 7.0, '2026-06-15'),
('DataSoft Inc', 'Data Analytics', 14.0, 5, 8.0, '2026-06-20'),
('CloudBase', 'Cloud Computing', 13.0, 8, 7.5, '2026-07-01'),
('AI Solutions', 'Artificial Intelligence', 15.0, 3, 8.5, '2026-07-10'),
('WebDev Pro', 'Web Development', 10.0, 12, 6.5, '2026-06-25');

-- Indexes for performance
CREATE INDEX idx_students_cgpa ON students(cgpa);
CREATE INDEX idx_companies_mincgpa ON companies(min_cgpa);
CREATE INDEX idx_applications_status ON applications(status);
CREATE INDEX idx_applications_dates ON applications(app_date);
