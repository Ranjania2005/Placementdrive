package com.example.placementdrive.service;

import com.example.placementdrive.db.DBConnection;
import com.example.placementdrive.model.Application;
import com.example.placementdrive.model.Company;
import com.example.placementdrive.model.Student;
import com.example.placementdrive.util.InputUtil;

import java.sql.*;
import java.time.LocalDate;

public class ApplicationService {
    private StudentService stdService = new StudentService();
    private CompanyService compService = new CompanyService();
    
    public void chkElig(int stdId) {
        Student std = stdService.getStdById(stdId);
        if (std == null) {
            InputUtil.printLine("Student not found!");
            return;
        }
        
        InputUtil.printSeparator();
        InputUtil.printLine("ELIGIBLE COMPANIES FOR: " + std.getName());
        InputUtil.printSeparator();
        
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM companies WHERE min_cgpa <= ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setDouble(1, std.getCgpa());
                try (ResultSet rs = pstmt.executeQuery()) {
                    boolean found = false;
                    while (rs.next()) {
                        found = true;
                        Company comp = new Company(
                            rs.getInt("comp_id"),
                            rs.getString("comp_name"),
                            rs.getString("industry"),
                            rs.getDouble("salary"),
                            rs.getInt("openings"),
                            rs.getDouble("min_cgpa"),
                            rs.getString("drive_date")
                        );
                        InputUtil.printLine(comp.toString());
                    }
                    if (!found) {
                        InputUtil.printLine("No eligible companies found for your CGPA!");
                    }
                }
            }
        } catch (SQLException e) {
            InputUtil.printLine("Error checking eligibility: " + e.getMessage());
        }
    }
    
    public void applyDrive() {
        int stdId = InputUtil.getInt("Enter Student ID: ");
        Student std = stdService.getStdById(stdId);
        
        if (std == null) {
            InputUtil.printLine("Student not found!");
            return;
        }
        
        int compId = InputUtil.getInt("Enter Company ID: ");
        Company comp = compService.getCompById(compId);
        
        if (comp == null) {
            InputUtil.printLine("Company not found!");
            return;
        }
        
        if (std.getCgpa() < comp.getMinCgpa()) {
            InputUtil.printLine("Student is not eligible for this company (CGPA: " + std.getCgpa() + 
                              ", Required: " + comp.getMinCgpa() + ")");
            return;
        }
        
        try (Connection conn = DBConnection.getConnection()) {
            // Check if already applied
            String checkSql = "SELECT * FROM applications WHERE std_id = ? AND comp_id = ?";
            try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
                checkStmt.setInt(1, stdId);
                checkStmt.setInt(2, compId);
                try (ResultSet rs = checkStmt.executeQuery()) {
                    if (rs.next()) {
                        InputUtil.printLine("Student already applied to this company!");
                        return;
                    }
                }
            }
            
            String sql = "INSERT INTO applications (std_id, comp_id, app_date, status) " +
                        "VALUES (?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, stdId);
                pstmt.setInt(2, compId);
                pstmt.setString(3, LocalDate.now().toString());
                pstmt.setString(4, "Applied");
                pstmt.executeUpdate();
                InputUtil.printLine("Application submitted successfully!");
            }
        } catch (SQLException e) {
            InputUtil.printLine("Error submitting application: " + e.getMessage());
        }
    }
    
    public void showAppliedStd() {
        int compId = InputUtil.getInt("Enter Company ID: ");
        Company comp = compService.getCompById(compId);
        
        if (comp == null) {
            InputUtil.printLine("Company not found!");
            return;
        }
        
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT a.app_id, s.std_id, s.name, s.email, s.cgpa, a.app_date, a.status " +
                        "FROM applications a " +
                        "JOIN students s ON a.std_id = s.std_id " +
                        "WHERE a.comp_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, compId);
                try (ResultSet rs = pstmt.executeQuery()) {
                    InputUtil.printSeparator();
                    InputUtil.printLine("APPLIED STUDENTS FOR: " + comp.getCompName());
                    InputUtil.printSeparator();
                    
                    boolean found = false;
                    while (rs.next()) {
                        found = true;
                        InputUtil.printLine("App ID: " + rs.getInt("app_id") + " | Student: " + 
                                          rs.getString("name") + " | ID: " + rs.getInt("std_id") + 
                                          " | Email: " + rs.getString("email") + " | CGPA: " + 
                                          rs.getDouble("cgpa") + " | Status: " + rs.getString("status"));
                    }
                    if (!found) {
                        InputUtil.printLine("No applications found for this company!");
                    }
                }
            }
        } catch (SQLException e) {
            InputUtil.printLine("Error fetching applications: " + e.getMessage());
        }
    }
    
    public void updateResult() {
        int appId = InputUtil.getInt("Enter Application ID: ");
        String newStatus = InputUtil.getString("Enter New Status (Selected/Rejected): ");
        
        if (!newStatus.equals("Selected") && !newStatus.equals("Rejected")) {
            InputUtil.printLine("Invalid status!");
            return;
        }
        
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "UPDATE applications SET status = ? WHERE app_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, newStatus);
                pstmt.setInt(2, appId);
                int rowsUpdated = pstmt.executeUpdate();
                if (rowsUpdated > 0) {
                    InputUtil.printLine("Status updated successfully!");
                } else {
                    InputUtil.printLine("Application not found!");
                }
            }
        } catch (SQLException e) {
            InputUtil.printLine("Error updating status: " + e.getMessage());
        }
    }
    
    public void showStats() {
        try (Connection conn = DBConnection.getConnection()) {
            InputUtil.printSeparator();
            InputUtil.printLine("PLACEMENT STATISTICS");
            InputUtil.printSeparator();
            
            // Total students
            String sql1 = "SELECT COUNT(*) as count FROM students";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sql1)) {
                if (rs.next()) {
                    InputUtil.printLine("Total Students: " + rs.getInt("count"));
                }
            }
            
            // Total companies
            String sql2 = "SELECT COUNT(*) as count FROM companies";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sql2)) {
                if (rs.next()) {
                    InputUtil.printLine("Total Companies: " + rs.getInt("count"));
                }
            }
            
            // Total applications
            String sql3 = "SELECT COUNT(*) as count FROM applications";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sql3)) {
                if (rs.next()) {
                    InputUtil.printLine("Total Applications: " + rs.getInt("count"));
                }
            }
            
            // Selected students
            String sql4 = "SELECT COUNT(DISTINCT std_id) as count FROM applications WHERE status = 'Selected'";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sql4)) {
                if (rs.next()) {
                    InputUtil.printLine("Selected Students: " + rs.getInt("count"));
                }
            }
            
            // Rejected applications
            String sql5 = "SELECT COUNT(*) as count FROM applications WHERE status = 'Rejected'";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sql5)) {
                if (rs.next()) {
                    InputUtil.printLine("Rejected Applications: " + rs.getInt("count"));
                }
            }
            
        } catch (SQLException e) {
            InputUtil.printLine("Error fetching statistics: " + e.getMessage());
        }
    }
}
