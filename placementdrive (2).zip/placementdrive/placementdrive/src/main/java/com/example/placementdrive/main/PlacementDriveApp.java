package com.example.placementdrive.main;

import com.example.placementdrive.service.*;
import com.example.placementdrive.util.InputUtil;

public class PlacementDriveApp {
    
    public static void main(String[] args) {
        PlacementDriveApp app = new PlacementDriveApp();
        app.start();
    }
    
    private void start() {
        AdminService adminService = new AdminService();
        StudentService stdService = new StudentService();
        CompanyService compService = new CompanyService();
        ApplicationService appService = new ApplicationService();
        
        boolean running = true;
        
        InputUtil.printSeparator();
        InputUtil.printLine("PLACEMENT DRIVE MANAGEMENT SYSTEM");
        InputUtil.printSeparator();
        
        if (!adminService.login()) {
            InputUtil.printLine("Cannot proceed without admin authentication!");
            return;
        }
        
        while (running) {
            showMainMenu();
            int choice = InputUtil.getInt("Enter your choice: ");
            
            switch (choice) {
                case 1:
                    stdService.addStd();
                    break;
                case 2:
                    compService.addComp();
                    break;
                case 3:
                    stdService.showAllStd();
                    break;
                case 4:
                    compService.showComp();
                    break;
                case 5:
                    int stdId = InputUtil.getInt("Enter Student ID: ");
                    appService.chkElig(stdId);
                    break;
                case 6:
                    appService.applyDrive();
                    break;
                case 7:
                    appService.showAppliedStd();
                    break;
                case 8:
                    appService.updateResult();
                    break;
                case 9:
                    appService.showStats();
                    break;
                case 10:
                    InputUtil.printLine("Searching...");
                    int searchChoice = InputUtil.getInt("Search (1=Student, 2=Company): ");
                    if (searchChoice == 1) {
                        stdService.searchStd();
                    } else if (searchChoice == 2) {
                        compService.searchComp();
                    }
                    break;
                case 11:
                    running = false;
                    InputUtil.printLine("Thank you! Exiting...");
                    break;
                default:
                    InputUtil.printLine("Invalid choice!");
            }
        }
    }
    
    private void showMainMenu() {
        InputUtil.printSeparator();
        InputUtil.printLine("MAIN MENU");
        InputUtil.printLine("1. Add Student");
        InputUtil.printLine("2. Add Company");
        InputUtil.printLine("3. View All Students");
        InputUtil.printLine("4. View All Companies");
        InputUtil.printLine("5. Check Student Eligibility");
        InputUtil.printLine("6. Apply for Company Drive");
        InputUtil.printLine("7. View Applied Students (for Company)");
        InputUtil.printLine("8. Update Interview Result");
        InputUtil.printLine("9. View Placement Statistics");
        InputUtil.printLine("10. Search Student/Company");
        InputUtil.printLine("11. Exit");
        InputUtil.printSeparator();
    }
}
