package com.example.placementdrive.service;

import com.example.placementdrive.db.DBConnection;
import com.example.placementdrive.model.Company;
import com.example.placementdrive.util.InputUtil;

import java.sql.*;

public class CompanyService {
    
    public void addComp() {
        try (Connection conn = DBConnection.getConnection()) {
            String compName = InputUtil.getString("Enter Company Name: ");
            String industry = InputUtil.getString("Enter Industry: ");
            double salary = InputUtil.getDouble("Enter Salary (LPA): ");
            int openings = InputUtil.getInt("Enter Number of Openings: ");
            double minCgpa = InputUtil.getDouble("Enter Minimum CGPA required: ");
            String driveDate = InputUtil.getString("Enter Drive Date (YYYY-MM-DD): ");
            
            String sql = "INSERT INTO companies (comp_name, industry, salary, openings, min_cgpa, drive_date) " +
                        "VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, compName);
                pstmt.setString(2, industry);
                pstmt.setDouble(3, salary);
                pstmt.setInt(4, openings);
                pstmt.setDouble(5, minCgpa);
                pstmt.setString(6, driveDate);
                pstmt.executeUpdate();
                InputUtil.printLine("Company added successfully!");
            }
        } catch (SQLException e) {
            InputUtil.printLine("Error adding company: " + e.getMessage());
        }
    }
    
    public void showComp() {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM companies";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sql)) {
                
                InputUtil.printSeparator();
                InputUtil.printLine("ALL COMPANIES");
                InputUtil.printSeparator();
                
                boolean found = false;
                while (rs.next()) {
                    found = true;
                    Company comp = new Company(
                        rs.getInt("comp_id"),
                        rs.getString("comp_name"),
                        rs.getString("industry"),
                        rs.getDouble("salary"),
                        rs.getInt("openings"),
                        rs.getDouble("min_cgpa"),
                        rs.getString("drive_date")
                    );
                    InputUtil.printLine(comp.toString());
                }
                if (!found) {
                    InputUtil.printLine("No companies found!");
                }
            }
        } catch (SQLException e) {
            InputUtil.printLine("Error fetching companies: " + e.getMessage());
        }
    }
    
    public void searchComp() {
        String compName = InputUtil.getString("Enter Company Name: ");
        
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM companies WHERE comp_name LIKE ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, "%" + compName + "%");
                try (ResultSet rs = pstmt.executeQuery()) {
                    InputUtil.printSeparator();
                    InputUtil.printLine("SEARCH RESULTS");
                    InputUtil.printSeparator();
                    
                    boolean found = false;
                    while (rs.next()) {
                        found = true;
                        Company comp = new Company(
                            rs.getInt("comp_id"),
                            rs.getString("comp_name"),
                            rs.getString("industry"),
                            rs.getDouble("salary"),
                            rs.getInt("openings"),
                            rs.getDouble("min_cgpa"),
                            rs.getString("drive_date")
                        );
                        InputUtil.printLine(comp.toString());
                    }
                    if (!found) {
                        InputUtil.printLine("No companies found with that name!");
                    }
                }
            }
        } catch (SQLException e) {
            InputUtil.printLine("Error searching company: " + e.getMessage());
        }
    }
    
    public Company getCompById(int compId) {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM companies WHERE comp_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, compId);
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        return new Company(
                            rs.getInt("comp_id"),
                            rs.getString("comp_name"),
                            rs.getString("industry"),
                            rs.getDouble("salary"),
                            rs.getInt("openings"),
                            rs.getDouble("min_cgpa"),
                            rs.getString("drive_date")
                        );
                    }
                }
            }
        } catch (SQLException e) {
            InputUtil.printLine("Error fetching company: " + e.getMessage());
        }
        return null;
    }
}
