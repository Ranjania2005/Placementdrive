package com.example.placementdrive.model;

public class Student {
    private int stdId;
    private String name;
    private String email;
    private double cgpa;
    private int branchId;
    
    public Student() {
    }
    
    public Student(int stdId, String name, String email, double cgpa, int branchId) {
        this.stdId = stdId;
        this.name = name;
        this.email = email;
        this.cgpa = cgpa;
        this.branchId = branchId;
    }
    
    public int getStdId() {
        return stdId;
    }
    
    public void setStdId(int stdId) {
        this.stdId = stdId;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public double getCgpa() {
        return cgpa;
    }
    
    public void setCgpa(double cgpa) {
        this.cgpa = cgpa;
    }
    
    public int getBranchId() {
        return branchId;
    }
    
    public void setBranchId(int branchId) {
        this.branchId = branchId;
    }
    
    @Override
    public String toString() {
        return "ID: " + stdId + " | Name: " + name + " | Email: " + email + 
               " | CGPA: " + cgpa + " | Branch ID: " + branchId;
    }
}
