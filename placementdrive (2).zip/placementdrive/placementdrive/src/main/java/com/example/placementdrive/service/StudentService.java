package com.example.placementdrive.service;

import com.example.placementdrive.db.DBConnection;
import com.example.placementdrive.model.Student;
import com.example.placementdrive.util.InputUtil;

import java.sql.*;

public class StudentService {
    
    public void addStd() {
        try (Connection conn = DBConnection.getConnection()) {
            String name = InputUtil.getString("Enter Student Name: ");
            String email = InputUtil.getString("Enter Email: ");
            double cgpa = InputUtil.getDouble("Enter CGPA: ");
            int branch = InputUtil.getInt("Enter Branch ID (1=CSE, 2=ECE, 3=ME): ");
            
            String sql = "INSERT INTO students (name, email, cgpa, branch_id) VALUES (?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, name);
                pstmt.setString(2, email);
                pstmt.setDouble(3, cgpa);
                pstmt.setInt(4, branch);
                pstmt.executeUpdate();
                InputUtil.printLine("Student added successfully!");
            }
        } catch (SQLException e) {
            InputUtil.printLine("Error adding student: " + e.getMessage());
        }
    }
    
    public void showAllStd() {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM students";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sql)) {
                
                InputUtil.printSeparator();
                InputUtil.printLine("ALL STUDENTS");
                InputUtil.printSeparator();
                
                boolean found = false;
                while (rs.next()) {
                    found = true;
                    Student std = new Student(
                        rs.getInt("std_id"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getDouble("cgpa"),
                        rs.getInt("branch_id")
                    );
                    InputUtil.printLine(std.toString());
                }
                if (!found) {
                    InputUtil.printLine("No students found!");
                }
            }
        } catch (SQLException e) {
            InputUtil.printLine("Error fetching students: " + e.getMessage());
        }
    }
    
    public void searchStd() {
        String name = InputUtil.getString("Enter Student Name: ");
        
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM students WHERE name LIKE ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, "%" + name + "%");
                try (ResultSet rs = pstmt.executeQuery()) {
                    InputUtil.printSeparator();
                    InputUtil.printLine("SEARCH RESULTS");
                    InputUtil.printSeparator();
                    
                    boolean found = false;
                    while (rs.next()) {
                        found = true;
                        Student std = new Student(
                            rs.getInt("std_id"),
                            rs.getString("name"),
                            rs.getString("email"),
                            rs.getDouble("cgpa"),
                            rs.getInt("branch_id")
                        );
                        InputUtil.printLine(std.toString());
                    }
                    if (!found) {
                        InputUtil.printLine("No students found with that name!");
                    }
                }
            }
        } catch (SQLException e) {
            InputUtil.printLine("Error searching student: " + e.getMessage());
        }
    }
    
    public Student getStdById(int stdId) {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM students WHERE std_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, stdId);
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        return new Student(
                            rs.getInt("std_id"),
                            rs.getString("name"),
                            rs.getString("email"),
                            rs.getDouble("cgpa"),
                            rs.getInt("branch_id")
                        );
                    }
                }
            }
        } catch (SQLException e) {
            InputUtil.printLine("Error fetching student: " + e.getMessage());
        }
        return null;
    }
}
