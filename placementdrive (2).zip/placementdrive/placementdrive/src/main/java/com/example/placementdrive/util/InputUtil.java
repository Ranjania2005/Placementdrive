package com.example.placementdrive.util;

import java.util.Scanner;

public class InputUtil {
    private static Scanner sc = new Scanner(System.in);
    
    public static int getInt(String prompt) {
        System.out.print(prompt);
        try {
            return sc.nextInt();
        } finally {
            sc.nextLine();
        }
    }
    
    public static String getString(String prompt) {
        System.out.print(prompt);
        return sc.nextLine();
    }
    
    public static double getDouble(String prompt) {
        System.out.print(prompt);
        try {
            return sc.nextDouble();
        } finally {
            sc.nextLine();
        }
    }
    
    public static void printLine(String msg) {
        System.out.println(msg);
    }
    
    public static void print(String msg) {
        System.out.print(msg);
    }
    
    public static void printSeparator() {
        System.out.println("========================================");
    }
}
