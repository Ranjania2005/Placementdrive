package com.example.placementdrive.model;

public class Application {
    private int appId;
    private int stdId;
    private int compId;
    private String appDate;
    private String status;
    
    public Application() {
    }
    
    public Application(int appId, int stdId, int compId, String appDate, String status) {
        this.appId = appId;
        this.stdId = stdId;
        this.compId = compId;
        this.appDate = appDate;
        this.status = status;
    }
    
    public int getAppId() {
        return appId;
    }
    
    public void setAppId(int appId) {
        this.appId = appId;
    }
    
    public int getStdId() {
        return stdId;
    }
    
    public void setStdId(int stdId) {
        this.stdId = stdId;
    }
    
    public int getCompId() {
        return compId;
    }
    
    public void setCompId(int compId) {
        this.compId = compId;
    }
    
    public String getAppDate() {
        return appDate;
    }
    
    public void setAppDate(String appDate) {
        this.appDate = appDate;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    @Override
    public String toString() {
        return "App ID: " + appId + " | Student ID: " + stdId + " | Company ID: " + compId + 
               " | Date: " + appDate + " | Status: " + status;
    }
}
