package com.example.placementdrive.model;

public class Company {
    private int compId;
    private String compName;
    private String industry;
    private double salary;
    private int openings;
    private double minCgpa;
    private String driveDate;
    
    public Company() {
    }
    
    public Company(int compId, String compName, String industry, double salary, 
                   int openings, double minCgpa, String driveDate) {
        this.compId = compId;
        this.compName = compName;
        this.industry = industry;
        this.salary = salary;
        this.openings = openings;
        this.minCgpa = minCgpa;
        this.driveDate = driveDate;
    }
    
    public int getCompId() {
        return compId;
    }
    
    public void setCompId(int compId) {
        this.compId = compId;
    }
    
    public String getCompName() {
        return compName;
    }
    
    public void setCompName(String compName) {
        this.compName = compName;
    }
    
    public String getIndustry() {
        return industry;
    }
    
    public void setIndustry(String industry) {
        this.industry = industry;
    }
    
    public double getSalary() {
        return salary;
    }
    
    public void setSalary(double salary) {
        this.salary = salary;
    }
    
    public int getOpenings() {
        return openings;
    }
    
    public void setOpenings(int openings) {
        this.openings = openings;
    }
    
    public double getMinCgpa() {
        return minCgpa;
    }
    
    public void setMinCgpa(double minCgpa) {
        this.minCgpa = minCgpa;
    }
    
    public String getDriveDate() {
        return driveDate;
    }
    
    public void setDriveDate(String driveDate) {
        this.driveDate = driveDate;
    }
    
    @Override
    public String toString() {
        return "ID: " + compId + " | Company: " + compName + " | Industry: " + industry + 
               " | Salary: " + salary + " LPA | Openings: " + openings + 
               " | Min CGPA: " + minCgpa + " | Date: " + driveDate;
    }
}
