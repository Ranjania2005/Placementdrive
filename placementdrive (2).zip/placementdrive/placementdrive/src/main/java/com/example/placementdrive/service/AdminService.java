package com.example.placementdrive.service;

import com.example.placementdrive.util.InputUtil;

public class AdminService {
    private static final String ADMIN_ID = "admin";
    private static final String ADMIN_PASSWORD = "admin123";
    
    public boolean login() {
        InputUtil.printSeparator();
        InputUtil.printLine("ADMIN LOGIN");
        InputUtil.printSeparator();
        
        String id = InputUtil.getString("Enter Admin ID: ");
        String password = InputUtil.getString("Enter Password: ");
        
        if (id.equals(ADMIN_ID) && password.equals(ADMIN_PASSWORD)) {
            InputUtil.printLine("Login Successful!");
            return true;
        } else {
            InputUtil.printLine("Invalid Credentials!");
            return false;
        }
    }
}
